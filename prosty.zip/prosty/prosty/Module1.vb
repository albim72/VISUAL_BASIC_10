﻿Module Module1

    Sub Main()
        Console.WriteLine("To jest pierwsza aplikacja")
        Console.WriteLine("Druga linia...")
        Console.ReadKey()

        Dim imie = "Ryszard"
        Dim nazwisko As String = "Kot"
        Dim wiek = 45
        Dim latapracy As Integer = 5

        MsgBox(VarType(imie))
        MsgBox(VarType(nazwisko))
        MsgBox(VarType(wiek))
        MsgBox(VarType(latapracy))

        'komentowanie linii - bloku CTRL+K, CTRL+C
        'odkomentowanie CTRL+K, CTRL+U

        wiek = 55.5
        MsgBox(VarType(wiek))
        MsgBox(3 * wiek)

        Dim cena = 12.99

        MsgBox(VarType(cena))
        MsgBox(3 * cena)

        MsgBox(IsNumeric(wiek))
        MsgBox(IsNumeric(cena))





    End Sub

End Module
