﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnZamknij = New System.Windows.Forms.Button()
        Me.btnKwota = New System.Windows.Forms.Button()
        Me.btnZam = New System.Windows.Forms.Button()
        Me.rtbZam = New System.Windows.Forms.RichTextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.cbCzo = New System.Windows.Forms.CheckBox()
        Me.cbTun = New System.Windows.Forms.CheckBox()
        Me.cbPom = New System.Windows.Forms.CheckBox()
        Me.cbPie = New System.Windows.Forms.CheckBox()
        Me.cbSzy = New System.Windows.Forms.CheckBox()
        Me.cbSer = New System.Windows.Forms.CheckBox()
        Me.cbCeb = New System.Windows.Forms.CheckBox()
        Me.cbPep = New System.Windows.Forms.CheckBox()
        Me.lbOdbior = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbGodzina = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rbGrube = New System.Windows.Forms.RadioButton()
        Me.rbCienkie = New System.Windows.Forms.RadioButton()
        Me.rbStandard = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rbDuza = New System.Windows.Forms.RadioButton()
        Me.rbSrednia = New System.Windows.Forms.RadioButton()
        Me.rbMala = New System.Windows.Forms.RadioButton()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(520, 639)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(1)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(108, 29)
        Me.btnReset.TabIndex = 14
        Me.btnReset.Text = "Wyczyść"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnZamknij
        '
        Me.btnZamknij.Location = New System.Drawing.Point(371, 639)
        Me.btnZamknij.Margin = New System.Windows.Forms.Padding(1)
        Me.btnZamknij.Name = "btnZamknij"
        Me.btnZamknij.Size = New System.Drawing.Size(108, 29)
        Me.btnZamknij.TabIndex = 15
        Me.btnZamknij.Text = "Zamknij"
        Me.btnZamknij.UseVisualStyleBackColor = True
        '
        'btnKwota
        '
        Me.btnKwota.Location = New System.Drawing.Point(222, 639)
        Me.btnKwota.Margin = New System.Windows.Forms.Padding(1)
        Me.btnKwota.Name = "btnKwota"
        Me.btnKwota.Size = New System.Drawing.Size(108, 29)
        Me.btnKwota.TabIndex = 16
        Me.btnKwota.Text = "Kwota"
        Me.btnKwota.UseVisualStyleBackColor = True
        '
        'btnZam
        '
        Me.btnZam.Location = New System.Drawing.Point(73, 639)
        Me.btnZam.Margin = New System.Windows.Forms.Padding(1)
        Me.btnZam.Name = "btnZam"
        Me.btnZam.Size = New System.Drawing.Size(108, 29)
        Me.btnZam.TabIndex = 17
        Me.btnZam.Text = "Zamówienie"
        Me.btnZam.UseVisualStyleBackColor = True
        '
        'rtbZam
        '
        Me.rtbZam.Location = New System.Drawing.Point(69, 449)
        Me.rtbZam.Margin = New System.Windows.Forms.Padding(1)
        Me.rtbZam.Name = "rtbZam"
        Me.rtbZam.Size = New System.Drawing.Size(559, 171)
        Me.rtbZam.TabIndex = 13
        Me.rtbZam.Text = ""
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.cbCzo)
        Me.GroupBox3.Controls.Add(Me.cbTun)
        Me.GroupBox3.Controls.Add(Me.cbPom)
        Me.GroupBox3.Controls.Add(Me.cbPie)
        Me.GroupBox3.Controls.Add(Me.cbSzy)
        Me.GroupBox3.Controls.Add(Me.cbSer)
        Me.GroupBox3.Controls.Add(Me.cbCeb)
        Me.GroupBox3.Controls.Add(Me.cbPep)
        Me.GroupBox3.Location = New System.Drawing.Point(483, 32)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox3.Size = New System.Drawing.Size(142, 391)
        Me.GroupBox3.TabIndex = 12
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "dodatki"
        '
        'cbCzo
        '
        Me.cbCzo.AutoSize = True
        Me.cbCzo.Location = New System.Drawing.Point(10, 302)
        Me.cbCzo.Margin = New System.Windows.Forms.Padding(1)
        Me.cbCzo.Name = "cbCzo"
        Me.cbCzo.Size = New System.Drawing.Size(66, 17)
        Me.cbCzo.TabIndex = 0
        Me.cbCzo.Text = "czosnek"
        Me.cbCzo.UseVisualStyleBackColor = True
        '
        'cbTun
        '
        Me.cbTun.AutoSize = True
        Me.cbTun.Location = New System.Drawing.Point(10, 265)
        Me.cbTun.Margin = New System.Windows.Forms.Padding(1)
        Me.cbTun.Name = "cbTun"
        Me.cbTun.Size = New System.Drawing.Size(63, 17)
        Me.cbTun.TabIndex = 0
        Me.cbTun.Text = "tuńczyk"
        Me.cbTun.UseVisualStyleBackColor = True
        '
        'cbPom
        '
        Me.cbPom.AutoSize = True
        Me.cbPom.Location = New System.Drawing.Point(10, 227)
        Me.cbPom.Margin = New System.Windows.Forms.Padding(1)
        Me.cbPom.Name = "cbPom"
        Me.cbPom.Size = New System.Drawing.Size(63, 17)
        Me.cbPom.TabIndex = 0
        Me.cbPom.Text = "pomidor"
        Me.cbPom.UseVisualStyleBackColor = True
        '
        'cbPie
        '
        Me.cbPie.AutoSize = True
        Me.cbPie.Location = New System.Drawing.Point(10, 190)
        Me.cbPie.Margin = New System.Windows.Forms.Padding(1)
        Me.cbPie.Name = "cbPie"
        Me.cbPie.Size = New System.Drawing.Size(68, 17)
        Me.cbPie.TabIndex = 0
        Me.cbPie.Text = "pieczarki"
        Me.cbPie.UseVisualStyleBackColor = True
        '
        'cbSzy
        '
        Me.cbSzy.AutoSize = True
        Me.cbSzy.Location = New System.Drawing.Point(10, 153)
        Me.cbSzy.Margin = New System.Windows.Forms.Padding(1)
        Me.cbSzy.Name = "cbSzy"
        Me.cbSzy.Size = New System.Drawing.Size(59, 17)
        Me.cbSzy.TabIndex = 0
        Me.cbSzy.Text = "szynka"
        Me.cbSzy.UseVisualStyleBackColor = True
        '
        'cbSer
        '
        Me.cbSer.AutoSize = True
        Me.cbSer.Location = New System.Drawing.Point(10, 115)
        Me.cbSer.Margin = New System.Windows.Forms.Padding(1)
        Me.cbSer.Name = "cbSer"
        Me.cbSer.Size = New System.Drawing.Size(40, 17)
        Me.cbSer.TabIndex = 0
        Me.cbSer.Text = "ser"
        Me.cbSer.UseVisualStyleBackColor = True
        '
        'cbCeb
        '
        Me.cbCeb.AutoSize = True
        Me.cbCeb.Location = New System.Drawing.Point(10, 78)
        Me.cbCeb.Margin = New System.Windows.Forms.Padding(1)
        Me.cbCeb.Name = "cbCeb"
        Me.cbCeb.Size = New System.Drawing.Size(58, 17)
        Me.cbCeb.TabIndex = 0
        Me.cbCeb.Text = "cebula"
        Me.cbCeb.UseVisualStyleBackColor = True
        '
        'cbPep
        '
        Me.cbPep.AutoSize = True
        Me.cbPep.Location = New System.Drawing.Point(10, 41)
        Me.cbPep.Margin = New System.Windows.Forms.Padding(1)
        Me.cbPep.Name = "cbPep"
        Me.cbPep.Size = New System.Drawing.Size(73, 17)
        Me.cbPep.TabIndex = 0
        Me.cbPep.Text = "pepperoni"
        Me.cbPep.UseVisualStyleBackColor = True
        '
        'lbOdbior
        '
        Me.lbOdbior.FormattingEnabled = True
        Me.lbOdbior.Items.AddRange(New Object() {"osobisty", "dowóz", "kurier", "catering"})
        Me.lbOdbior.Location = New System.Drawing.Point(275, 291)
        Me.lbOdbior.Margin = New System.Windows.Forms.Padding(1)
        Me.lbOdbior.Name = "lbOdbior"
        Me.lbOdbior.Size = New System.Drawing.Size(141, 134)
        Me.lbOdbior.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(273, 250)
        Me.Label2.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "odbiór"
        '
        'lbGodzina
        '
        Me.lbGodzina.FormattingEnabled = True
        Me.lbGodzina.Items.AddRange(New Object() {"15:00", "16:00", "17:00", "18:00", "19:00", "20:00", "21:00", "22:00"})
        Me.lbGodzina.Location = New System.Drawing.Point(69, 291)
        Me.lbGodzina.Margin = New System.Windows.Forms.Padding(1)
        Me.lbGodzina.Name = "lbGodzina"
        Me.lbGodzina.Size = New System.Drawing.Size(141, 134)
        Me.lbGodzina.TabIndex = 11
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(66, 250)
        Me.Label1.Margin = New System.Windows.Forms.Padding(1, 0, 1, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(58, 13)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "rezerwacja"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rbGrube)
        Me.GroupBox2.Controls.Add(Me.rbCienkie)
        Me.GroupBox2.Controls.Add(Me.rbStandard)
        Me.GroupBox2.Location = New System.Drawing.Point(275, 32)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox2.Size = New System.Drawing.Size(141, 185)
        Me.GroupBox2.TabIndex = 6
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "ciasto"
        '
        'rbGrube
        '
        Me.rbGrube.AutoSize = True
        Me.rbGrube.Location = New System.Drawing.Point(21, 128)
        Me.rbGrube.Margin = New System.Windows.Forms.Padding(1)
        Me.rbGrube.Name = "rbGrube"
        Me.rbGrube.Size = New System.Drawing.Size(52, 17)
        Me.rbGrube.TabIndex = 0
        Me.rbGrube.TabStop = True
        Me.rbGrube.Text = "grube"
        Me.rbGrube.UseVisualStyleBackColor = True
        '
        'rbCienkie
        '
        Me.rbCienkie.AutoSize = True
        Me.rbCienkie.Location = New System.Drawing.Point(21, 41)
        Me.rbCienkie.Margin = New System.Windows.Forms.Padding(1)
        Me.rbCienkie.Name = "rbCienkie"
        Me.rbCienkie.Size = New System.Drawing.Size(59, 17)
        Me.rbCienkie.TabIndex = 0
        Me.rbCienkie.TabStop = True
        Me.rbCienkie.Text = "cienkie"
        Me.rbCienkie.UseVisualStyleBackColor = True
        '
        'rbStandard
        '
        Me.rbStandard.AutoSize = True
        Me.rbStandard.Location = New System.Drawing.Point(21, 84)
        Me.rbStandard.Margin = New System.Windows.Forms.Padding(1)
        Me.rbStandard.Name = "rbStandard"
        Me.rbStandard.Size = New System.Drawing.Size(86, 17)
        Me.rbStandard.TabIndex = 0
        Me.rbStandard.TabStop = True
        Me.rbStandard.Text = "standardowe"
        Me.rbStandard.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rbDuza)
        Me.GroupBox1.Controls.Add(Me.rbSrednia)
        Me.GroupBox1.Controls.Add(Me.rbMala)
        Me.GroupBox1.Location = New System.Drawing.Point(66, 32)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(1)
        Me.GroupBox1.Size = New System.Drawing.Size(141, 185)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "rozmiar"
        '
        'rbDuza
        '
        Me.rbDuza.AutoSize = True
        Me.rbDuza.Location = New System.Drawing.Point(14, 128)
        Me.rbDuza.Margin = New System.Windows.Forms.Padding(1)
        Me.rbDuza.Name = "rbDuza"
        Me.rbDuza.Size = New System.Drawing.Size(48, 17)
        Me.rbDuza.TabIndex = 0
        Me.rbDuza.TabStop = True
        Me.rbDuza.Text = "duża"
        Me.rbDuza.UseVisualStyleBackColor = True
        '
        'rbSrednia
        '
        Me.rbSrednia.AutoSize = True
        Me.rbSrednia.Location = New System.Drawing.Point(14, 84)
        Me.rbSrednia.Margin = New System.Windows.Forms.Padding(1)
        Me.rbSrednia.Name = "rbSrednia"
        Me.rbSrednia.Size = New System.Drawing.Size(59, 17)
        Me.rbSrednia.TabIndex = 0
        Me.rbSrednia.TabStop = True
        Me.rbSrednia.Text = "średnia"
        Me.rbSrednia.UseVisualStyleBackColor = True
        '
        'rbMala
        '
        Me.rbMala.AutoSize = True
        Me.rbMala.Location = New System.Drawing.Point(14, 41)
        Me.rbMala.Margin = New System.Windows.Forms.Padding(1)
        Me.rbMala.Name = "rbMala"
        Me.rbMala.Size = New System.Drawing.Size(49, 17)
        Me.rbMala.TabIndex = 0
        Me.rbMala.TabStop = True
        Me.rbMala.Text = "mała"
        Me.rbMala.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(710, 703)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnZamknij)
        Me.Controls.Add(Me.btnKwota)
        Me.Controls.Add(Me.btnZam)
        Me.Controls.Add(Me.rtbZam)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.lbOdbior)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lbGodzina)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "PIZZERIA"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnReset As Button
    Friend WithEvents btnZamknij As Button
    Friend WithEvents btnKwota As Button
    Friend WithEvents btnZam As Button
    Friend WithEvents rtbZam As RichTextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents cbCzo As CheckBox
    Friend WithEvents cbTun As CheckBox
    Friend WithEvents cbPom As CheckBox
    Friend WithEvents cbPie As CheckBox
    Friend WithEvents cbSzy As CheckBox
    Friend WithEvents cbSer As CheckBox
    Friend WithEvents cbCeb As CheckBox
    Friend WithEvents cbPep As CheckBox
    Friend WithEvents lbOdbior As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lbGodzina As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rbGrube As RadioButton
    Friend WithEvents rbCienkie As RadioButton
    Friend WithEvents rbStandard As RadioButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rbDuza As RadioButton
    Friend WithEvents rbSrednia As RadioButton
    Friend WithEvents rbMala As RadioButton
End Class
