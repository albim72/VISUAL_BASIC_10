﻿Public Class Form1
    Dim arrName As SortedDictionary(Of Integer, String)
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        arrName = New SortedDictionary(Of Integer, String)
        MainPage()
    End Sub

    Private Sub MainPage()
        Dim strhtml As String
        strhtml = "<html><body><h3>Lista osób</h3>"
        strhtml += "<input type=name id=txname>&nbsp;"
        strhtml += "<input type=button id=btnadd value='Dodaj osobę' onclick=""location.href='schname://add'""><br>"

        For Each id As Integer In arrName.Keys
            strhtml = strhtml & id & ". " & arrName(id) &
                "<a href='schname://delete?id=" & id & "'>[usuń element]</a><br>"
        Next
        strhtml = strhtml & "</body></html>"

        WebBrowser1.DocumentText = strhtml
    End Sub

    Private Sub AddName()
        Dim txelem As HtmlElement
        txelem = WebBrowser1.Document.GetElementById("txname")
        Dim strname As String = ""

        If (IsDBNull(txelem) = False) Then
            strname = txelem.GetAttribute("value")
        End If

        Dim lastname As KeyValuePair(Of Integer, String)
        Dim nextid As Integer

        If arrName.Count > 0 Then
            lastname = arrName.Last()
            nextid = lastname.Key + 1
        Else
            nextid = 1
        End If
        arrName.Add(nextid, strname)
    End Sub

    Private Sub DeleteName(ByVal id As Integer)
        arrName.Remove(id)
    End Sub


    Private Function extract_querystring(ByVal strquery As String) As Dictionary(Of String, String)
        Dim strtemp As String = Replace(strquery, "?", "")
        Dim arrkeyval As String()
        Dim arrdict As New Dictionary(Of String, String)
        arrkeyval = strtemp.Split("&")

        For Each strkeyval As String In arrkeyval
            Dim pos As Integer
            Dim key, value As String

            pos = InStr(1, strkeyval, "=", Microsoft.VisualBasic.CompareMethod.Text)
            key = strkeyval.Substring(0, pos - 1)
            value = strkeyval.Substring(pos)
            arrdict.Add(key, value)
        Next
        Return arrdict
    End Function

    Private Sub WebBrowser1_DocumentCompleted(sender As Object, e As WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted

    End Sub

    Private Sub WebBrowser1_Navigating(sender As Object, e As WebBrowserNavigatingEventArgs) Handles WebBrowser1.Navigating
        Dim _get As Dictionary(Of String, String)

        Select Case e.Url.Scheme
            Case "schname"
                e.Cancel = True

                Select Case e.Url.Host
                    Case "add"
                        AddName()
                    Case "delete"
                        _get = extract_querystring(e.Url.Query)
                        DeleteName(_get("id"))

                End Select
                MainPage()
        End Select
    End Sub
End Class
