﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Formularz przesłania metodę dispose, aby wyczyścić listę składników.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wymagane przez Projektanta formularzy systemu Windows
    Private components As System.ComponentModel.IContainer

    'UWAGA: następująca procedura jest wymagana przez Projektanta formularzy systemu Windows
    'Możesz to modyfikować, używając Projektanta formularzy systemu Windows. 
    'Nie należy modyfikować za pomocą edytora kodu.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gridOsoba = New System.Windows.Forms.DataGridView()
        Me.DataSet1 = New System.Data.DataSet()
        Me.btnCzytaj = New System.Windows.Forms.Button()
        Me.btnZapisz = New System.Windows.Forms.Button()
        CType(Me.gridOsoba, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'gridOsoba
        '
        Me.gridOsoba.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.gridOsoba.Location = New System.Drawing.Point(104, 91)
        Me.gridOsoba.Name = "gridOsoba"
        Me.gridOsoba.RowHeadersWidth = 102
        Me.gridOsoba.RowTemplate.Height = 40
        Me.gridOsoba.Size = New System.Drawing.Size(1427, 603)
        Me.gridOsoba.TabIndex = 0
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "NewDataSet"
        '
        'btnCzytaj
        '
        Me.btnCzytaj.Location = New System.Drawing.Point(104, 771)
        Me.btnCzytaj.Name = "btnCzytaj"
        Me.btnCzytaj.Size = New System.Drawing.Size(331, 93)
        Me.btnCzytaj.TabIndex = 1
        Me.btnCzytaj.Text = "Czytaj dane"
        Me.btnCzytaj.UseVisualStyleBackColor = True
        '
        'btnZapisz
        '
        Me.btnZapisz.Location = New System.Drawing.Point(1200, 771)
        Me.btnZapisz.Name = "btnZapisz"
        Me.btnZapisz.Size = New System.Drawing.Size(331, 93)
        Me.btnZapisz.TabIndex = 1
        Me.btnZapisz.Text = "Zapisz dane"
        Me.btnZapisz.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(16.0!, 31.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1648, 975)
        Me.Controls.Add(Me.btnZapisz)
        Me.Controls.Add(Me.btnCzytaj)
        Me.Controls.Add(Me.gridOsoba)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.gridOsoba, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gridOsoba As DataGridView
    Friend WithEvents DataSet1 As DataSet
    Friend WithEvents btnCzytaj As Button
    Friend WithEvents btnZapisz As Button
End Class
