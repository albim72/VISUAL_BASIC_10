﻿Public Class Form1
    Private nazwapliku As String = "tabela.xml"

    Private Sub btnCzytaj_Click(sender As Object, e As EventArgs) Handles btnCzytaj.Click
        DataSet1.Clear()
        DataSet1.ReadXml(nazwapliku)
        gridOsoba.DataSource = DataSet1
        gridOsoba.DataMember = "osoba"
        btnCzytaj.Enabled = False
    End Sub

    Private Sub gridOsoba_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles gridOsoba.CellContentClick

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        btnZapisz.Enabled = False
    End Sub

    Private Sub gridOsoba_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles gridOsoba.CellValueChanged
        btnZapisz.Enabled = True
    End Sub

    Private Sub btnZapisz_Click(sender As Object, e As EventArgs) Handles btnZapisz.Click
        System.IO.File.Copy(nazwapliku, nazwapliku & ".bak", True)
        DataSet1.WriteXml(nazwapliku)

        btnZapisz.Enabled = False
    End Sub
End Class
